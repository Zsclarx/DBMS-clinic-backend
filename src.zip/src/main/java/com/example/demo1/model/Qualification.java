package com.example.demo1.model;

public class Qualification {
    private int doctorID;
    private String degree;

    public Qualification() {
    }

    // Getters and Setters
    // ...

    public int getDoctorID() {
        return doctorID;
    }

    public void setDoctorID(int doctorID) {
        this.doctorID = doctorID;
    }

    public String getDegree() {
        return degree;
    }

    public void setDegree(String degree) {
        this.degree = degree;
    }
}
