package com.example.demo1.model;

public class Description {
    private int appointmentID;
    private String problem;

    public Description() {
    }

    // Getters and Setters
    // ...

    public int getAppointmentID() {
        return appointmentID;
    }

    public void setAppointmentID(int appointmentID) {
        this.appointmentID = appointmentID;
    }

    public String getProblem() {
        return problem;
    }

    public void setProblem(String problem) {
        this.problem = problem;
    }
}
