package com.example.demo1.repository;

import com.example.demo1.model.TimeSlot;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.util.List;

@Repository
public class TimeSlotRepositoryImpl implements TimeSlotRepository {

    private final JdbcTemplate jdbcTemplate;

    // Constructor injection for JdbcTemplate
    public TimeSlotRepositoryImpl(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public void save(TimeSlot timeSlot) {
        validateTimeSlot(timeSlot); // Validate the TimeSlot object
        String sql = "INSERT INTO time_slots (doctorID, timeslot, workday) VALUES (?, ?, ?)";
        jdbcTemplate.update(sql, timeSlot.getDoctorID(), timeSlot.getTimeslot(), timeSlot.getWorkday());
    }

    @Override
    public TimeSlot findById(int doctorID, Time timeslot) {
        validateDoctorId(doctorID); // Validate doctorID
        validateTime(timeslot); // Validate timeslot
        String sql = "SELECT * FROM time_slots WHERE doctorID = ? AND timeslot = ?";
        try {
            return jdbcTemplate.queryForObject(sql, this::mapRowToTimeSlot, doctorID, timeslot);
        } catch (org.springframework.dao.EmptyResultDataAccessException e) {
            return null; // Handle not found case
        }
    }

    @Override
    public List<TimeSlot> findAll() {
        String sql = "SELECT * FROM time_slots";
        return jdbcTemplate.query(sql, this::mapRowToTimeSlot);
    }

    @Override
    public void update(TimeSlot timeSlot) {
        validateTimeSlot(timeSlot); // Validate the TimeSlot object
        String sql = "UPDATE time_slots SET workday = ? WHERE doctorID = ? AND timeslot = ?";
        jdbcTemplate.update(sql, timeSlot.getWorkday(), timeSlot.getDoctorID(), timeSlot.getTimeslot());
    }

    @Override
    public void delete(int doctorID, Time timeslot) {
        validateDoctorId(doctorID); // Validate doctorID
        validateTime(timeslot); // Validate timeslot
        String sql = "DELETE FROM time_slots WHERE doctorID = ? AND timeslot = ?";
        jdbcTemplate.update(sql, doctorID, timeslot);
    }

    // Validate TimeSlot object for null values
    private void validateTimeSlot(TimeSlot timeSlot) {
        if (timeSlot == null) {
            throw new IllegalArgumentException("TimeSlot cannot be null");
        }
        if (timeSlot.getTimeslot() == null) {
            throw new IllegalArgumentException("Timeslot cannot be null");
        }
        if (timeSlot.getWorkday() == null || timeSlot.getWorkday().isEmpty()) {
            throw new IllegalArgumentException("Workday cannot be null or empty");
        }
    }

    // Validate doctorID
    private void validateDoctorId(int doctorID) {
        if (doctorID <= 0) {
            throw new IllegalArgumentException("Invalid doctorID: must be a positive integer");
        }
    }

    // Validate timeslot
    private void validateTime(Time timeslot) {
        if (timeslot == null) {
            throw new IllegalArgumentException("Timeslot cannot be null");
        }
    }

    // Row mapper for TimeSlot
    private TimeSlot mapRowToTimeSlot(ResultSet rs, int rowNum) throws SQLException {
        TimeSlot timeSlot = new TimeSlot();
        timeSlot.setDoctorID(rs.getInt("doctorID"));
        timeSlot.setTimeslot(rs.getTime("timeslot"));
        timeSlot.setWorkday(rs.getString("workday"));
        return timeSlot;
    }
}
