package com.example.demo1.controller;

import com.example.demo1.model.MonthlyStatistics;
import com.example.demo1.service.MonthlyStatisticsService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/monthly-statistics")
public class MonthlyStatisticsController {

    private final MonthlyStatisticsService monthlyStatisticsService;

    public MonthlyStatisticsController(MonthlyStatisticsService monthlyStatisticsService) {
        this.monthlyStatisticsService = monthlyStatisticsService;
    }

    @PostMapping
    public ResponseEntity<?> createMonthlyStatistics(@RequestBody MonthlyStatistics statistics) {
        // Validate required fields
        if (statistics.getMonthName() == null || statistics.getMonthName().isEmpty()) {
            return new ResponseEntity<>("Month name cannot be null or empty", HttpStatus.BAD_REQUEST);
        }
        if (statistics.getTotalAppointments() < 0 || statistics.getTotalIncome() < 0 || statistics.getTotalUsersRegistered() < 0) {
            return new ResponseEntity<>("Total appointments, income, and users registered cannot be negative", HttpStatus.BAD_REQUEST);
        }

        int statID = monthlyStatisticsService.save(statistics);
        statistics.setStatID(statID);  // Set the generated ID in the response
        return new ResponseEntity<>(statistics, HttpStatus.CREATED);
    }

    @PutMapping("/{statID}")
    public ResponseEntity<?> updateMonthlyStatistics(@PathVariable int statID, @RequestBody MonthlyStatistics statistics) {
        if (statID <= 0) {
            return new ResponseEntity<>("Invalid stat ID", HttpStatus.BAD_REQUEST);
        }

        // Set the statID and validate
        statistics.setStatID(statID);
        if (statistics.getMonthName() == null || statistics.getMonthName().isEmpty()) {
            return new ResponseEntity<>("Month name cannot be null or empty", HttpStatus.BAD_REQUEST);
        }
        if (statistics.getTotalAppointments() < 0 || statistics.getTotalIncome() < 0 || statistics.getTotalUsersRegistered() < 0) {
            return new ResponseEntity<>("Total appointments, income, and users registered cannot be negative", HttpStatus.BAD_REQUEST);
        }

        int updatedRows = monthlyStatisticsService.update(statistics);
        if (updatedRows > 0) {
            return new ResponseEntity<>(statistics, HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Statistics not found", HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/{statID}")
    public ResponseEntity<?> getMonthlyStatisticsById(@PathVariable int statID) {
        if (statID <= 0) {
            return new ResponseEntity<>("Invalid stat ID", HttpStatus.BAD_REQUEST);
        }

        MonthlyStatistics statistics = monthlyStatisticsService.findById(statID);
        if (statistics != null) {
            return new ResponseEntity<>(statistics, HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Statistics not found", HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping
    public ResponseEntity<List<MonthlyStatistics>> getAllMonthlyStatistics() {
        List<MonthlyStatistics> statisticsList = monthlyStatisticsService.findAll();
        return new ResponseEntity<>(statisticsList, HttpStatus.OK);
    }

    @DeleteMapping("/{statID}")
    public ResponseEntity<?> deleteMonthlyStatistics(@PathVariable int statID) {
        if (statID <= 0) {
            return new ResponseEntity<>("Invalid stat ID", HttpStatus.BAD_REQUEST);
        }

        int deletedRows = monthlyStatisticsService.deleteById(statID);
        if (deletedRows > 0) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } else {
            return new ResponseEntity<>("Statistics not found", HttpStatus.NOT_FOUND);
        }
    }
}
