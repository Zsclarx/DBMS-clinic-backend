package com.example.demo1.controller;

import com.example.demo1.model.WeeklyStatistics;
import com.example.demo1.service.WeeklyStatisticsService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("/api/statistics")
public class WeeklyStatisticsController {

    private final WeeklyStatisticsService weeklyStatisticsService;

    public WeeklyStatisticsController(WeeklyStatisticsService weeklyStatisticsService) {
        this.weeklyStatisticsService = weeklyStatisticsService;
    }

    @PostMapping
    public ResponseEntity<String> saveStatistics(@RequestBody WeeklyStatistics statistics) {
        try {
            int statID = weeklyStatisticsService.saveStatistics(statistics);
            return ResponseEntity.ok("Statistics saved with ID: " + statID);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PutMapping
    public ResponseEntity<String> updateStatistics(@RequestBody WeeklyStatistics statistics) {
        try {
            int updatedRows = weeklyStatisticsService.updateStatistics(statistics);
            return ResponseEntity.ok("Statistics updated: " + updatedRows);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping("/{statID}")
    public ResponseEntity<WeeklyStatistics> findStatisticsById(@PathVariable int statID) {
        try {
            WeeklyStatistics statistics = weeklyStatisticsService.findStatisticsById(statID);
            return ResponseEntity.ok(statistics);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(null);
        }
    }

    @GetMapping
    public ResponseEntity<List<WeeklyStatistics>> findAllStatistics() {
        List<WeeklyStatistics> statisticsList = weeklyStatisticsService.findAllStatistics();
        return ResponseEntity.ok(statisticsList);
    }

    @DeleteMapping("/{statID}")
    public ResponseEntity<String> deleteStatisticsById(@PathVariable int statID) {
        try {
            int deletedRows = weeklyStatisticsService.deleteStatisticsById(statID);
            return ResponseEntity.ok("Statistics deleted: " + deletedRows);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}
