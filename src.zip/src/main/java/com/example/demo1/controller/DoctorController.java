package com.example.demo1.controller;

import com.example.demo1.model.Doctor;
import com.example.demo1.service.DoctorService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/doctors")
public class DoctorController {

    private final DoctorService doctorService;

    public DoctorController(DoctorService doctorService) {
        this.doctorService = doctorService;
    }

    @PostMapping
    public ResponseEntity<String> createDoctor(@RequestBody Doctor doctor) {
        if (doctor == null) {
            return ResponseEntity.badRequest().body("Doctor cannot be null");
        }
        int result = doctorService.saveDoctor(doctor);
        return ResponseEntity.ok("Doctor saved with ID: " + result);
    }

    @PutMapping("/{doctorID}")
    public ResponseEntity<String> updateDoctor(@RequestBody Doctor doctor) {
        if (doctor == null) {
            return ResponseEntity.badRequest().body("Doctor cannot be null");
        }
        int result = doctorService.updateDoctor(doctor);
        return ResponseEntity.ok("Doctor updated with ID: " + result);
    }

    @GetMapping("/{doctorID}")
    public ResponseEntity<Doctor> getDoctorById(@PathVariable int doctorID) {
        if (doctorID <= 0) {
            return ResponseEntity.badRequest().body(null);
        }
        Doctor doctor = doctorService.findDoctorById(doctorID);
        return ResponseEntity.ok(doctor);
    }

    @GetMapping
    public ResponseEntity<List<Doctor>> getAllDoctors() {
        List<Doctor> doctors = doctorService.findAllDoctors();
        return ResponseEntity.ok(doctors);
    }

    @GetMapping("/department/{departmentID}")
    public ResponseEntity<List<Doctor>> getDoctorsByDepartmentId(@PathVariable int departmentID) {
        if (departmentID <= 0) {
            return ResponseEntity.badRequest().body(null);
        }
        List<Doctor> doctors = doctorService.findDoctorsByDepartmentId(departmentID);
        return ResponseEntity.ok(doctors);
    }

    @DeleteMapping("/{doctorID}")
    public ResponseEntity<String> deleteDoctor(@PathVariable int doctorID) {
        if (doctorID <= 0) {
            return ResponseEntity.badRequest().body("Doctor ID must be positive");
        }
        doctorService.deleteDoctorById(doctorID);
        return ResponseEntity.ok("Doctor deleted with ID: " + doctorID);
    }
}
