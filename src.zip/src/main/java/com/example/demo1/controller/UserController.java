package com.example.demo1.controller;

import com.example.demo1.model.User;
import com.example.demo1.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.sql.SQLException;
import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("/users")
public class UserController {

    private final UserService userService;

    @Autowired
    public UserController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/{id}")
    public ResponseEntity<User> getUserById(@PathVariable int id) {
        try {
            User user = userService.findById(id);
            return user != null ? ResponseEntity.ok(user) : ResponseEntity.notFound().build();
        } catch (SQLException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }

    @GetMapping
    public ResponseEntity<List<User>> getAllUsers() {
        try {
            List<User> users = userService.findAll();
            return ResponseEntity.ok(users);
        } catch (SQLException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }

    @PostMapping
    public ResponseEntity<User> createUser(@RequestBody User user) {
        try {
            userService.save(user);
            return ResponseEntity.status(HttpStatus.CREATED).body(user);
        } catch (SQLException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<User> updateUser(@PathVariable int id, @RequestBody User user) {
        try {
            User existingUser = userService.findById(id);
            if (existingUser == null) {
                return ResponseEntity.notFound().build();
            }

            // Update each field with error handling
            try {
                if (user.getUsername() != null) {
                    existingUser.setUsername(user.getUsername());
                }
            } catch (Exception e) {
                return ResponseEntity.badRequest().body(null);
            }

            try {
                if (user.getPassword() != null) {
                    existingUser.setPassword(user.getPassword());
                }
            } catch (Exception e) {
                return ResponseEntity.badRequest().body(null);
            }

            try {
                if (user.getRole() != null) {
                    existingUser.setRole(user.getRole());
                }
            } catch (Exception e) {
                return ResponseEntity.badRequest().body(null);
            }

            try {
                if (user.getContactInfo() != null) {
                    existingUser.setContactInfo(user.getContactInfo());
                }
            } catch (Exception e) {
                return ResponseEntity.badRequest().body(null);
            }

            // Continue for other fields...
            try {
                if (user.getYearOfBirth() != 0) {
                    existingUser.setYearOfBirth(user.getYearOfBirth());
                }
            } catch (Exception e) {
                return ResponseEntity.badRequest().body(null);
            }

            try {
                if (user.getMonthOfBirth() != 0) {
                    existingUser.setMonthOfBirth(user.getMonthOfBirth());
                }
            } catch (Exception e) {
                return ResponseEntity.badRequest().body(null);
            }

            try {
                if (user.getDayOfBirth() != 0) {
                    existingUser.setDayOfBirth(user.getDayOfBirth());
                }
            } catch (Exception e) {
                return ResponseEntity.badRequest().body(null);
            }

            try {
                if (user.getBloodGroup() != null) {
                    existingUser.setBloodGroup(user.getBloodGroup());
                }
            } catch (Exception e) {
                return ResponseEntity.badRequest().body(null);
            }

            try {
                if (user.getFirstName() != null) {
                    existingUser.setFirstName(user.getFirstName());
                }
            } catch (Exception e) {
                return ResponseEntity.badRequest().body(null);
            }

            try {
                if (user.getLastName() != null) {
                    existingUser.setLastName(user.getLastName());
                }
            } catch (Exception e) {
                return ResponseEntity.badRequest().body(null);
            }

            try {
                if (user.getAge() != 0) {
                    existingUser.setAge(user.getAge());
                }
            } catch (Exception e) {
                return ResponseEntity.badRequest().body(null);
            }

            try {
                if (user.getEmail() != null) {
                    existingUser.setEmail(user.getEmail());
                }
            } catch (Exception e) {
                return ResponseEntity.badRequest().body(null);
            }

            try {
                if (user.getAddress() != null) {
                    existingUser.setAddress(user.getAddress());
                }
            } catch (Exception e) {
                return ResponseEntity.badRequest().body(null);
            }

            try {
                if (user.getGender() != null) {
                    existingUser.setGender(user.getGender());
                }
            } catch (Exception e) {
                return ResponseEntity.badRequest().body(null);
            }

//            userService.update(existingUser); // Save updated user

            return ResponseEntity.ok(existingUser);
        } catch (SQLException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteUser(@PathVariable int id) {
        try {
            userService.delete(id);
            return ResponseEntity.noContent().build();
        } catch (SQLException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
}
