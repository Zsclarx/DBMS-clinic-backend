package com.example.demo1.controller;

import com.example.demo1.model.Appointment;
import com.example.demo1.service.AppointmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/appointments")
public class AppointmentController {

    @Autowired
    private AppointmentService appointmentService;

    // Save a new appointment
    @PostMapping("/save")
    public ResponseEntity<Void> saveAppointment(@RequestBody Appointment appointment) {
        appointmentService.save(appointment);
        return ResponseEntity.status(201).build(); // Return 201 Created
    }

    // Get an appointment by ID
    @GetMapping("/{id}")
    public ResponseEntity<Appointment> getAppointmentById(@PathVariable int id) {
        Appointment appointment = appointmentService.findById(id);
        if (appointment == null) {
            return ResponseEntity.notFound().build(); // Return 404 Not Found
        }
        return ResponseEntity.ok(appointment); // Return 200 OK and the appointment
    }

    // Get all appointments
    @GetMapping("/all")
    public ResponseEntity<List<Appointment>> getAllAppointments() {
        List<Appointment> appointments = appointmentService.findAll();
        return ResponseEntity.ok(appointments); // Return 200 OK and the list of appointments
    }

    // Update an existing appointment
    @PutMapping("/update")
    public ResponseEntity<Void> updateAppointment(@RequestBody Appointment appointment) {
        // You might want to check if the appointment exists before updating
        appointmentService.update(appointment);
        return ResponseEntity.noContent().build(); // Return 204 No Content
    }

    // Delete an appointment by ID
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Void> deleteAppointment(@PathVariable int id) {
        Appointment appointment = appointmentService.findById(id);
        if (appointment == null) {
            return ResponseEntity.notFound().build(); // Return 404 Not Found
        }
        appointmentService.delete(id);
        return ResponseEntity.noContent().build(); // Return 204 No Content
    }
    // Get all appointments by patient ID
    @GetMapping("/patient/{patientId}")
    public ResponseEntity<List<Appointment>> getAppointmentsByPatientId(@PathVariable int patientId) {
        List<Appointment> appointments = appointmentService.findByPatientId(patientId);
        if (appointments.isEmpty()) {
            return ResponseEntity.noContent().build(); // Return 204 No Content if no appointments found
        }
        return ResponseEntity.ok(appointments); // Return 200 OK and the list of appointments
    }

}
