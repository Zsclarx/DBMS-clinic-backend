package com.example.demo1.controller;

import com.example.demo1.model.TimeSlot;
import com.example.demo1.service.TimeSlotService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.sql.Time;
import java.util.List;

@RestController
@RequestMapping("/api/timeslots")
public class TimeSlotController {

    private final TimeSlotService timeSlotService;

    @Autowired
    public TimeSlotController(TimeSlotService timeSlotService) {
        this.timeSlotService = timeSlotService;
    }

    @PostMapping
    public ResponseEntity<Void> createTimeSlot(@RequestBody TimeSlot timeSlot) {
        try {
            timeSlotService.save(timeSlot);
            return new ResponseEntity<>(HttpStatus.CREATED);
        } catch (IllegalArgumentException e) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/{doctorID}/{timeslot}")
    public ResponseEntity<TimeSlot> getTimeSlot(@PathVariable int doctorID, @PathVariable Time timeslot) {
        try {
            TimeSlot timeSlot = timeSlotService.findById(doctorID, timeslot);
            if (timeSlot != null) {
                return new ResponseEntity<>(timeSlot, HttpStatus.OK);
            } else {
                return new ResponseEntity<>(HttpStatus.NOT_FOUND);
            }
        } catch (IllegalArgumentException e) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping
    public ResponseEntity<List<TimeSlot>> getAllTimeSlots() {
        List<TimeSlot> timeSlots = timeSlotService.findAll();
        return new ResponseEntity<>(timeSlots, HttpStatus.OK);
    }

    @PutMapping
    public ResponseEntity<Void> updateTimeSlot(@RequestBody TimeSlot timeSlot) {
        try {
            timeSlotService.update(timeSlot);
            return new ResponseEntity<>(HttpStatus.OK);
        } catch (IllegalArgumentException e) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }

    @DeleteMapping("/{doctorID}/{timeslot}")
    public ResponseEntity<Void> deleteTimeSlot(@PathVariable int doctorID, @PathVariable Time timeslot) {
        try {
            timeSlotService.delete(doctorID, timeslot);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (IllegalArgumentException e) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }
}
