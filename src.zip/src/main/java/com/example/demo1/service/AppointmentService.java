package com.example.demo1.service;

import com.example.demo1.model.Appointment;
import java.util.List;

public interface AppointmentService {
    void save(Appointment appointment);
    Appointment findById(int id);
    List<Appointment> findAll();
    void update(Appointment appointment);
    void delete(int id);

    List<Appointment> findByPatientId(int patientId);
}
