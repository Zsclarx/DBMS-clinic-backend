package com.example.demo1.service;

import com.example.demo1.model.MonthlyStatistics;

import java.util.List;

public interface MonthlyStatisticsService {
    int save(MonthlyStatistics statistics);
    int update(MonthlyStatistics statistics);
    MonthlyStatistics findById(int statID);
    List<MonthlyStatistics> findAll();
    int deleteById(int statID);
}
