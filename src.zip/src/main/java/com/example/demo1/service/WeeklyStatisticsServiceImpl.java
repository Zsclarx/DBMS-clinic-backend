package com.example.demo1.service;

import com.example.demo1.model.WeeklyStatistics;
import com.example.demo1.repository.WeeklyStatisticsRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class WeeklyStatisticsServiceImpl implements WeeklyStatisticsService {

    private final WeeklyStatisticsRepository weeklyStatisticsRepository;

    public WeeklyStatisticsServiceImpl(WeeklyStatisticsRepository weeklyStatisticsRepository) {
        this.weeklyStatisticsRepository = weeklyStatisticsRepository;
    }

    @Override
    public int saveStatistics(WeeklyStatistics statistics) {
        if (statistics == null) {
            throw new IllegalArgumentException("WeeklyStatistics cannot be null");
        }
        return weeklyStatisticsRepository.save(statistics);
    }

    @Override
    public int updateStatistics(WeeklyStatistics statistics) {
        if (statistics == null) {
            throw new IllegalArgumentException("WeeklyStatistics cannot be null");
        }
        return weeklyStatisticsRepository.update(statistics);
    }

    @Override
    public WeeklyStatistics findStatisticsById(int statID) {
        if (statID <= 0) {
            throw new IllegalArgumentException("Stat ID must be positive");
        }
        return weeklyStatisticsRepository.findById(statID);
    }

    @Override
    public List<WeeklyStatistics> findAllStatistics() {
        return weeklyStatisticsRepository.findAll();
    }

    @Override
    public int deleteStatisticsById(int statID) {
        if (statID <= 0) {
            throw new IllegalArgumentException("Stat ID must be positive");
        }
        return weeklyStatisticsRepository.deleteById(statID);
    }
}
