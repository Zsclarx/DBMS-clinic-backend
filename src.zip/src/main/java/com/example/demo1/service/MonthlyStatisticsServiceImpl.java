package com.example.demo1.service;

import com.example.demo1.model.MonthlyStatistics;
import com.example.demo1.repository.MonthlyStatisticsRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MonthlyStatisticsServiceImpl implements MonthlyStatisticsService {

    private final MonthlyStatisticsRepository monthlyStatisticsRepository;

    public MonthlyStatisticsServiceImpl(MonthlyStatisticsRepository monthlyStatisticsRepository) {
        this.monthlyStatisticsRepository = monthlyStatisticsRepository;
    }

    @Override
    public int save(MonthlyStatistics statistics) {
        return monthlyStatisticsRepository.save(statistics);
    }

    @Override
    public int update(MonthlyStatistics statistics) {
        return monthlyStatisticsRepository.update(statistics);
    }

    @Override
    public MonthlyStatistics findById(int statID) {
        return monthlyStatisticsRepository.findById(statID);
    }

    @Override
    public List<MonthlyStatistics> findAll() {
        return monthlyStatisticsRepository.findAll();
    }

    @Override
    public int deleteById(int statID) {
        return monthlyStatisticsRepository.deleteById(statID);
    }
}
