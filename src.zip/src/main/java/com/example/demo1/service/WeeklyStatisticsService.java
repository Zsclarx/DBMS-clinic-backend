package com.example.demo1.service;

import com.example.demo1.model.WeeklyStatistics;

import java.util.List;

public interface WeeklyStatisticsService {
    int saveStatistics(WeeklyStatistics statistics);
    int updateStatistics(WeeklyStatistics statistics);
    WeeklyStatistics findStatisticsById(int statID);
    List<WeeklyStatistics> findAllStatistics();
    int deleteStatisticsById(int statID);
}
